<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>

  <meta content="en-gb" http-equiv="Content-Language">

  <meta content="Microsoft FrontPage 6.0" name="GENERATOR">

  <meta content="FrontPage.Editor.Document" name="ProgId">

  <meta content="text/html; charset=windows-1252" http-equiv="Content-Type">

  <meta name="robots" content="noindex, noFOLLOW">
  <title>Exit Profit Generator!</title>
<link rel="shortcut icon" type="image/ico" href="http://exitprofitgenerator.com/favicon.ico">

<?php require_once('class.JavaScriptPacker.php');
$site = "http://";
$site .= $_SERVER["HTTP_HOST"];
$full = ($_SERVER["REQUEST_URI"]);
$path = $site.$full;

if(empty($_REQUEST['overlayurl'])) $_REQUEST['overlayurl'] = $path.'black.png';
if(empty($_REQUEST['width'])) $_REQUEST['width'] = 500;
if(empty($_REQUEST['height'])) $_REQUEST['height'] = 400;
if(empty($_REQUEST['bordercolor'])) $_REQUEST['bordercolor'] = '#000000';
if(empty($_REQUEST['bgtitle'])) $_REQUEST['bgtitle'] = '#0000FF';
if(empty($_REQUEST['texttitle'])) $_REQUEST['texttitle'] = '#ffffff';
if(empty($_REQUEST['affid'])) $_REQUEST['affid'] = 'salinafn';
if(empty($_REQUEST['affok'])) $_REQUEST['affok'] = 'Yes';
if(empty($_REQUEST['display'])) $_REQUEST['display'] = -1;
if ($_REQUEST['affok']=='Yes'){
$powered="<center><a href='https://paydotcom.com/r/18464/".$_REQUEST["affid"]."/1553508/' target=_blank style='font-family:verdana; font-size:10px;'>Powered by Exit Profit Generator</a></center>";
}else{
if ($_REQUEST['affok']=='No'){
$powered=" ";
}
}
$script = file_get_contents("_jscode.js");
$script = str_replace('__width__',$_REQUEST['width'],$script);
$script = str_replace('__height__',$_REQUEST['height'],$script);
$script = str_replace('__bordercolor__',$_REQUEST['bordercolor'],$script);
$script = str_replace('__bgtitle__',$_REQUEST['bgtitle'],$script);
$script = str_replace('__texttitle__',$_REQUEST['texttitle'],$script);
$script = str_replace('__url__',$_REQUEST['url'],$script);
$script = str_replace('__overlayurl__',$_REQUEST['overlayurl'],$script);
$script = str_replace('__affid__',$_REQUEST['affid'],$script);
$script = str_replace('__display__',$_REQUEST['display'],$script);

$script = str_replace('__affmsg__',$powered,$script);
$myPacker = new JavaScriptPacker($script);
$output = $myPacker->pack();
$output = '<!--##BEGIN_EXIT_SCRIPT##--><script>'."\r\n".$output."</script><!--##END_EXIT_SCRIPT##-->";
?>
  <style>
<!--
h1 { font-family: Tahoma; font-size: 16pt; letter-spacing: -1pt; font-weight: bold }
.body { font-family: Verdana; font-size: 11pt }
li { font-family: Verdana; font-size: 10pt; margin-bottom: 10pt; }
.bodysmall { font-family: Verdana; font-size: 10pt }
.tt { border-width: 1px; border-color: #000000; border-style: solid; background-color: #ffffbc; }
textarea { font-family: Verdana; font-size: 10pt }
h2 { font-family: Tahoma; font-size: 13pt; letter-spacing: -1; font-weight: bold }
.order { font-family: Tahoma; font-size: 14pt; letter-spacing: -1; font-weight: bold }
-->
  </style>
<script SRC="http://hur-ta-hur.com/rotator/thankyousignup.js"></script></head>


<body background="http://exitprofitgenerator.com/script/EPG/black.png">

<div align="center">
<center>
<table style="border-collapse: collapse;" bgcolor="#ffffff" border="1" bordercolor="#c0c0c0" cellpadding="0" cellspacing="0" width="680">

  <tbody>

    <tr>

      <td> <font face="Verdana"> <img src="header.jpg" border="0">
      </font>
      <div align="center">
      <center>
      <table style="border-collapse: collapse; width: 646px; height: 0px;" border="0" bordercolor="#111111" cellpadding="0" cellspacing="0">

        <tbody>

          <tr>

            <td width="100%">
			<p align="center">&nbsp;</p>
			<p align="center"><font face="Verdana">&nbsp;<b><a target="_blank" href="http://www.exitprofitgenerator.com/colorchart.htm">For
			Color Codes Click Here</a></b><br><br>
            *ATTENTION: Code will not work on websites where SSI calls are used*  :(<br>

            </font>

            </p>
<BR><BR>
            <p class="body"><font style="font-size: 11pt;" face="Verdana">
            <span lang="en-gb">
            <form action="" method="get">Width: <font face="Verdana"> <input name="width" size="5" value="<?php echo $_REQUEST['width'];?>" type="text"></font>
              <br>

              <br>

Height: <font face="Verdana"> <input name="height" size="5" value="<?php echo $_REQUEST['height'];?>" type="text"></font><br>

              <br>

Border color: <font face="Verdana"> <input size="10" name="bordercolor" value="<?php echo $_REQUEST['bordercolor'];?>" type="text"></font><br>

              <br>

Title background color: <font face="Verdana"> <input size="10" name="bgtitle" value="<?php echo $_REQUEST['bgtitle'];?>" type="text"></font><br>

              <br>

Number of times to Display: <font face="Verdana"><input size="10" name="display" value="<?php echo $_REQUEST['display'];?>" type="text"></font><br>
-1 is infinite, 1 is once per session, 2 is twice per session etc...<br>
              <br>

URL of popup content: <font face="Verdana"> <input size="48" name="url" value="<?php echo $_REQUEST['url'];?>" type="text"><br>
You must have already created the webpage that will show in the popup or have the URL of whatever site you want to load in the popup.</font><br><br>

              <br>
				Overlay image (This is image that will completely cover the screen when the popup is activated): <br>

<table width="100%">
<?
$handle = opendir (dirname( __FILE__ ));
$count = 1;

$link = "http://".$_SERVER['SERVER_NAME'].substr($_SERVER['PHP_SELF'],0,strrpos($_SERVER['PHP_SELF'], "/")+1);

 while (false !== ($file = @readdir ($handle)))
  {
  if (strpos($file, ".png"))
   {

	if($count == 1) echo "<tr>";

	$checked = "";
	if ($_REQUEST['overlayurl']==$link.$file) $checked = " checked";
   echo "<td><input name=\"overlayurl\" value=\"".$link.$file."\" type=\"radio\"".$checked."><img src=\"".$link.$file."\" height=\"25\" width=\"25\"></td>";

	if($count == 5) {
	echo "</tr>";
	$count = 0;
	}

	$count++;

   }
  }

if($count == 2) echo "<td></td><td></td><td></td><td></td></tr>";
elseif($count == 3) echo "<td></td><td></td><td></td></tr>";
elseif($count == 4) echo "<td></td><td></td></tr>";
elseif($count == 5) echo "<td></td></tr>";
?>
</table>


<p>


              <br>
				<b>Affiliate Program: </b> </span></strong></font><font face="Verdana"></span>
				</font></p>
				</p>
              <p class="style10"><font face="Verdana">Do you want to make extra money (Yes or No)?
				</font> <span lang="en-gb"><font face="Verdana" style="font-size: 11pt;">
                <font face="Verdana">
                <input size="15" name="affok" value="<?php echo $_REQUEST['affok'];?>" type="text"><br>If you type in Yes, your PayDotCom affiliate URL will show under the popup, if you type No, nothing will appear under the popup.
				</font></font></span></p><br>
              <p><span lang="en-gb"><font face="Verdana" style="font-size: 11pt;"><strong><span class="style2"><span class="style11">
				PayDotCom Affiliate ID - </span></span></strong>
				<font face="Verdana">
                <input size="48" name="affid" value="<?php echo $_REQUEST['affid'];?>" type="text"><br>
				You will earn $10 per sale!&nbsp; You must be a PayDotCom Affiliate, if you are not yet, you can signup <a href="https://paydotcom.com/a.page.php?id=18464&u=salinafn" target=_new">here</a>.  Your affiliate link will show up under your popup.</font><br><br>
				<font face="Verdana">

              <input name="Submit" type="submit"></font>
              <br>

              <br>
	</form>


Paste this code in between the &lt;head&gt; &lt;/head&gt; tags:<br>
	<form action="test.php" method="post">
              <textarea rows="16" cols="60" name="txtOut"><?php echo $output;?></textarea>
        <br><input type="submit" value="Test">
	</form>
            <p align="center">

            <br>

			<a href="http://salinas-help.com" target=_new">Comments,
			Feedback, Questions?</a></p>
			<p align="left">
<font face="Verdana" style="font-size: 11pt">
<img src="http://franksalinas.com/me.JPG" width="73" border="0" height="73"></font></p>
<p class="MsoNormal" style="line-height: normal;" align="left">
<span style="font-family: Verdana;" lang="EN-CA">
<font style="font-size: 11pt;" face="Verdana">To your success,</font></span></p>
<p class="MsoNormal" style="line-height: normal;" align="left">
<span style="font-family: Verdana;" lang="en-ca">
<font style="font-size: 11pt;" face="Verdana">Frank Salinas</font></span></p>
<p align="left"><font face="Verdana" style="font-size: 11pt">
<img alt="" src="http://franksalinas.com/signature.png" width="260" height="76"></font></p>
<p align="left"><font face="Verdana" style="font-size: 11pt">
<a target="_blank" href="http://ExitTweetGenerator.com/free">
http://ExitTweetGenerator.com</a></font></p>
<p align="left"><font face="Verdana" style="font-size: 11pt">
<a target="_blank" href="http://imvideos4free.com/index.php?referid=invite">
http://IMVideos4Free.com</a></font></p>
<p align="left"><font face="Verdana" style="font-size: 11pt">
<a target="_blank" href="http://ResellRightsHandbook.com">
http://ResellRightsHandbook.com</a></font></p>
<p align="left"><font face="Verdana" style="font-size: 11pt">
<a target="_blank" href="http://TheIMDictionary.com">http://TheIMDictionary.com</a></font></p>
<p align="left"><font face="Verdana" style="font-size: 11pt">
<a target="_blank" href="http://YourEZAds.com">http://YourEZAds.com</a></font></p><hr>
			<p align="center">

            &nbsp;</p>
			<table id="table9" align="center" border="0" cellpadding="0" cellspacing="0" width="450">
				<tr>
					<td valign="top">
					<div align="center">
						<strong><font color="#cc0000" face="Tahoma" size="5">
					</div>
					</td>
				</tr>
			</table>
			<p align="center">
<p align="center"><strong><font face="Tahoma" color="#0033cc" size="5"><b><font size="4">Highly Recommended!</font></b></font></strong></p><strong><font face="Tahoma" color="#0033cc" size="5"></font></strong>
<center><strong><font face="Tahoma" color="#0033cc" size="5"></font></strong>
<p align="center"><strong><font face="Tahoma" color="#0033cc" size="5"><a href="http://tinyurl.com/amznbx" target="_blank"><img src="http://yourezads.com/images/sbox.jpg" border=0></a><br>
<center>
<script LANGUAGE="JavaScript" TYPE="text/javascript">
<!-- 
thankyousignup(); 
// --> 
</script></center></font></font></b><br><br>

            <p class="body" align="left">&nbsp;</p>

            </td>

          </tr>

        </tbody>
      </table>

      </center>

      </div>

      </td>

    </tr>

  </tbody>
</table>

</center>

</div>

<font face="Verdana">

<br>

</font>

<p style="margin-left: 40px; margin-right: 40px;" align="center"></p>

<p align="center">&nbsp;</p>

</body>
</html>