<?
phpinfo();
echo "TEST ".$_GET['test']." TEST";
?>