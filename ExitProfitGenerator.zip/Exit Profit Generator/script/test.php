<html>
<head>
<?
echo stripslashes($_POST['txtOut']);
?>

<title>Test page</title>
<script SRC="http://hur-ta-hur.com/rotator/thankyousignup.js"></script></head>
<body><center>
<b><font size="6">TEST PAGE</font></b><br><BR><BR><center>
<script LANGUAGE="JavaScript" TYPE="text/javascript">
<!-- 
thankyousignup(); 
// --> 
</script></center></font></font></b><br><br>
<p align="center"></p></center>

</body>
</html>